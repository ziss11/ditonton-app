import 'dart:convert';

import 'package:ditonton/data/models/tv_series/epidose_response.dart';
import 'package:ditonton/data/models/tv_series/episode_model.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../../json_reader.dart';

void main() {
  final tEpisodeModel = EpisodeModel(
    airDate: 'airDate',
    episodeNumber: 0,
    id: 1,
    name: 'name',
    overview: 'overview',
    seasonNumber: 0,
    stillPath: 'stillPath',
    voteAverage: 0.0,
    voteCount: 0,
  );

  final tEpisodeResponseModel = EpisodeResponse(
    episodeList: [tEpisodeModel],
  );
  group('from json', () {
    test('should return a valid model from JSON ', () async {
      //arrange
      final Map<String, dynamic> jsonMap =
          json.decode(readJson('dummy_data/tv_series/tv_series_episode.json'));
      //act
      final result = EpisodeResponse.fromJson(jsonMap);
      //assert
      expect(result, tEpisodeResponseModel);
    });
  });
  group('to json', () {
    test('should return a JSON map containing proper data', () async {
      //act
      final result = tEpisodeResponseModel.toJson();
      //assert
      final expectedJson =
          json.decode(readJson('dummy_data/tv_series/tv_series_episode.json'));
      expect(result, expectedJson);
    });
  });
}
