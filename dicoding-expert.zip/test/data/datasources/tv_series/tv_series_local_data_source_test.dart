import 'package:ditonton/common/exception.dart';
import 'package:ditonton/data/datasources/tv_series/tv_series_local_data_source.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import '../../../dummy_data/tv_series/dummy_tv_series_object.dart';
import '../../../helpers/test_helper.mocks.dart';

void main() {
  late MockDatabaseHelper mockDatabaseHelper;
  late TvSeriesLocalDataSourceImpl dataSource;

  setUp(() {
    mockDatabaseHelper = MockDatabaseHelper();
    dataSource =
        TvSeriesLocalDataSourceImpl(databaseHelper: mockDatabaseHelper);
  });

  group('Test Save Tv Series to Watchlist', () {
    test('should return success message when save to database is success ',
        () async {
      //assert
      when(mockDatabaseHelper.insertTvSeriesWatchlist(testtvSeriesTable))
          .thenAnswer((_) async => 1);
      //act
      final result = await dataSource.saveTvSeriesWatchlist(testtvSeriesTable);
      //assert
      expect(result, 'Added to Watchlist');
    });

    test('should throw DatabaseException when save to database is failed',
        () async {
      // arrange
      when(mockDatabaseHelper.insertTvSeriesWatchlist(testtvSeriesTable))
          .thenThrow(Exception());
      // act
      final call = dataSource.saveTvSeriesWatchlist(testtvSeriesTable);
      // assert
      expect(() => call, throwsA(isA<DatabaseException>()));
    });
  });

  group('Remove Tv Series from Watchlist', () {
    test('should return success message when remove from database is success',
        () async {
      //arrange
      when(mockDatabaseHelper.deleteTvSeriesWatchlist(testtvSeriesTable))
          .thenAnswer((_) async => 1);
      //act
      final result =
          await dataSource.removeTvSeriesWatchlist(testtvSeriesTable);
      //assert
      expect(result, 'Removed from Watchlist');
    });
    test('should throw DatabaseException when remove from database is failed',
        () async {
      // arrange
      when(mockDatabaseHelper.deleteTvSeriesWatchlist(testtvSeriesTable))
          .thenThrow(Exception());
      // act
      final call = dataSource.removeTvSeriesWatchlist(testtvSeriesTable);
      // assert
      expect(() => call, throwsA(isA<DatabaseException>()));
    });
  });
  group('Get Tv Series By Id', () {
    final tId = 1;
    test('should return Tv Series By Id when data is found', () async {
      //arrange
      when(mockDatabaseHelper.getTvSeriesById(tId))
          .thenAnswer((_) async => testTvSeriesMap);
      //act
      final result = await dataSource.getTvSeriesById(tId);
      //assert
      expect(result, testtvSeriesTable);
    });
    test('should return empty map when data id not found', () async {
      //arrange
      when(mockDatabaseHelper.getTvSeriesById(tId))
          .thenAnswer((_) async => null);
      //act
      final result = await dataSource.getTvSeriesById(tId);
      //assert
      expect(result, null);
    });
  });

  group('Get Tv Series List', () {
    test('should return Tv Series List from database', () async {
      //arrange
      when(mockDatabaseHelper.getTvSeriesWatchlist())
          .thenAnswer((_) async => [testTvSeriesMap]);
      //act
      final result = await dataSource.getTvSeriesWatchlist();
      //assert
      expect(result, [testtvSeriesTable]);
    });
    test('should return empty map when data id not found', () async {
      //arrange
      when(mockDatabaseHelper.getTvSeriesWatchlist()).thenThrow(Exception());
      //act
      final result = dataSource.getTvSeriesWatchlist();
      //assert
      expect(result, throwsA(isA<DatabaseException>()));
    });
  });
}
