import 'package:dartz/dartz.dart';
import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import '../../../dummy_data/tv_series/dummy_tv_series_object.dart';
import '../../../helpers/test_helper.mocks.dart';

void main() {
  late MockTvSeriesRepository mockTvSeriesRepository;
  late GetWatchlistTvSeries usecase;

  setUp(() {
    mockTvSeriesRepository = MockTvSeriesRepository();
    usecase = GetWatchlistTvSeries(mockTvSeriesRepository);
  });

  test('should get watchlist status from repository', () async {
    //arrange
    when(mockTvSeriesRepository.getTvSeriesWatchlist())
        .thenAnswer((_) async => Right(testTvSeriesList));
    //act
    final result = await usecase.execute();
    //assert
    verify(mockTvSeriesRepository.getTvSeriesWatchlist());
    expect(result, Right(testTvSeriesList));
  });
}
