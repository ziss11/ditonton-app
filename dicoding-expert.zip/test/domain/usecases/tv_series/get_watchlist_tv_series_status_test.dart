import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series_status.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import '../../../helpers/test_helper.mocks.dart';

void main() {
  late MockTvSeriesRepository mockTvSeriesRepository;
  late GetWatchlistTvSeriesStatus usecase;

  setUp(() {
    mockTvSeriesRepository = MockTvSeriesRepository();
    usecase = GetWatchlistTvSeriesStatus(mockTvSeriesRepository);
  });

  final tId = 1;
  test('should get watchlist status from repository', () async {
    //arrange
    when(mockTvSeriesRepository.isAddedToWatchlist(tId))
        .thenAnswer((_) async => true);
    //act
    final result = await usecase.execute(tId);
    //assert
    expect(result, true);
  });
}
