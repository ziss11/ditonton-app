import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series.dart';
import 'package:ditonton/presentation/provider/tv_series/watchlist_tv_series_notifier.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'watchlist_tv_series_notifier_test.mocks.dart';

@GenerateMocks([GetWatchlistTvSeries])
void main() {
  late WatchlistTvSeriesNotifier provider;
  late MockGetWatchlistTvSeries mockGetWatchlistTvSeries;
  late int listenerCallCount;

  setUp(() {
    listenerCallCount = 0;
    mockGetWatchlistTvSeries = MockGetWatchlistTvSeries();
    provider = WatchlistTvSeriesNotifier(
      watchlistTvSeries: mockGetWatchlistTvSeries,
    )..addListener(() {
        listenerCallCount++;
      });
  });

  final tTvSeries = TvSeries(
    backdropPath: 'backdropPath',
    firstAirDate: 'firstAirDate',
    id: 1,
    ids: [1, 2, 3],
    title: 'title',
    originCountry: ['originCountry'],
    originalLanguage: 'originalLanguage',
    originalName: 'originalName',
    overview: 'overview',
    popularity: 0,
    posterPath: 'posterPath',
    voteAverage: 0.0,
    voteCount: 0,
  );

  final tTvSeriesList = <TvSeries>[tTvSeries];

  group('Watchlist Tv Series', () {
    test('initialState should be Empty', () {
      expect(provider.watchlistState, RequestState.Empty);
    });
    test('should get data from usecase', () async {
      //arrange
      when(mockGetWatchlistTvSeries.execute())
          .thenAnswer((_) async => Right(tTvSeriesList));
      //act
      await provider.fetchWatchlistTvSeries();
      //assert
      verify(mockGetWatchlistTvSeries.execute());
    });
    test('should change state to Loading when data is called', () async {
      //arrange
      when(mockGetWatchlistTvSeries.execute())
          .thenAnswer((_) async => Right(tTvSeriesList));
      //act
      provider.fetchWatchlistTvSeries();
      //assert
      expect(provider.watchlistState, RequestState.Loading);
    });
    test('should change tv series when data is gotten successfully', () async {
      //arrange
      when(mockGetWatchlistTvSeries.execute())
          .thenAnswer((_) async => Right(tTvSeriesList));
      //act
      await provider.fetchWatchlistTvSeries();
      //assert
      expect(provider.watchlistState, RequestState.Loaded);
      expect(provider.watchlistTv, tTvSeriesList);
      expect(listenerCallCount, 1);
    });
    test('should return error when data is unsuccessful', () async {
      //arrange
      when(mockGetWatchlistTvSeries.execute())
          .thenAnswer((_) async => Left(ServerFailure('Server Failure')));
      //act
      await provider.fetchWatchlistTvSeries();
      //assert
      expect(provider.watchlistState, RequestState.Error);
      expect(provider.message, 'Server Failure');
      expect(listenerCallCount, 1);
    });
  });
}
