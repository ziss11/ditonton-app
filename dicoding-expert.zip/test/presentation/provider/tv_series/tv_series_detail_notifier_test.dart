import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/episode.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_detail_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_recommendation_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_tv_series_episode.dart';
import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series_status.dart';
import 'package:ditonton/domain/usecases/tv_series/remove_watchlist_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/save_watchlist_tv_series.dart';
import 'package:ditonton/presentation/provider/tv_series/tv_series_detail_notifier.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import '../../../dummy_data/tv_series/dummy_tv_series_object.dart';
import 'tv_series_detail_notifier_test.mocks.dart';

@GenerateMocks([
  GetDetailTvSeries,
  GetRecommendationTvSeries,
  GetWatchlistTvSeriesStatus,
  GetTvSeriesEpisode,
  SaveTvSeriesWatchlist,
  RemoveWatchlistTvSeries,
])
void main() {
  late TvSeriesDetailNotifier tvSeriesDetailNotifier;
  late MockGetDetailTvSeries mockGetDetailTvSeries;
  late MockGetRecommendationTvSeries mockGetRecommendationTvSeries;
  late MockGetTvSeriesEpisode mockGetTvSeriesEpisode;
  late MockGetWatchlistTvSeriesStatus mockGetWatchlistTvSeriesStatus;
  late MockSaveTvSeriesWatchlist mockSaveTvSeriesWatchlist;
  late MockRemoveWatchlistTvSeries mockRemoveWatchlistTvSeries;
  late int listenerCallCount;

  setUp(() {
    listenerCallCount = 0;
    mockRemoveWatchlistTvSeries = MockRemoveWatchlistTvSeries();
    mockSaveTvSeriesWatchlist = MockSaveTvSeriesWatchlist();
    mockGetRecommendationTvSeries = MockGetRecommendationTvSeries();
    mockGetWatchlistTvSeriesStatus = MockGetWatchlistTvSeriesStatus();
    mockGetTvSeriesEpisode = MockGetTvSeriesEpisode();
    mockGetDetailTvSeries = MockGetDetailTvSeries();
    tvSeriesDetailNotifier = TvSeriesDetailNotifier(
      getDetailTvSeries: mockGetDetailTvSeries,
      getRecommendationTvSeries: mockGetRecommendationTvSeries,
      getWatchListTvSeriesStatus: mockGetWatchlistTvSeriesStatus,
      getTvSeriesEpisode: mockGetTvSeriesEpisode,
      removeWatchlistTvSeries: mockRemoveWatchlistTvSeries,
      saveTvSeriesWatchlist: mockSaveTvSeriesWatchlist,
    )..addListener(() {
        listenerCallCount += 1;
      });
  });

  final tId = 1;
  final tSeason = 1;

  final tTvSeries = TvSeries(
    backdropPath: 'backdropPath',
    firstAirDate: 'firstAirDate',
    id: 1,
    ids: [1, 2, 3],
    title: 'title',
    originCountry: ['originCountry'],
    originalLanguage: 'originalLanguage',
    originalName: 'originalName',
    overview: 'overview',
    popularity: 0,
    posterPath: 'posterPath',
    voteAverage: 0.0,
    voteCount: 0,
  );

  final tEpisode = Episode(
    airDate: 'airDate',
    episodeNumber: 0,
    id: 1,
    name: 'name',
    overview: 'overview',
    seasonNumber: 0,
    stillPath: 'stillPath',
    voteAverage: 0.0,
    voteCount: 0,
  );

  final tTvSeriesList = <TvSeries>[tTvSeries];
  final tEpisodeList = <Episode>[tEpisode];

  void _arrangeUseCase() {
    when(mockGetDetailTvSeries.execute(tId))
        .thenAnswer((_) async => Right(testTvSeriesDetail));
    when(mockGetRecommendationTvSeries.execute(tId))
        .thenAnswer((_) async => Right(tTvSeriesList));
  }

  group('Get Tv Series Detail', () {
    test('should get data from the usecase', () async {
      //arange
      _arrangeUseCase();
      //act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      //assert
      verify(mockGetDetailTvSeries.execute(tId));
      verify(mockGetRecommendationTvSeries.execute(tId));
    });
    test('should change state to Loading when usecase is called ', () {
      //arrange
      _arrangeUseCase();
      //act
      tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      //assert
      expect(tvSeriesDetailNotifier.tvSeriesState, RequestState.Loading);
      expect(listenerCallCount, 1);
    });
    test('should change movie when data is gotten successfully', () async {
      // arrange
      _arrangeUseCase();
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      // assert
      expect(tvSeriesDetailNotifier.tvSeriesState, RequestState.Loaded);
      expect(tvSeriesDetailNotifier.tvSeriesDetail, testTvSeriesDetail);
      expect(listenerCallCount, 3);
    });
    test(
        'should change season and episode tv series when data is gotten successfully',
        () async {
      // arrange
      when(mockGetTvSeriesEpisode.execute(tId, tSeason))
          .thenAnswer((_) async => Right(tEpisodeList));
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesEpisode(tId, tSeason);
      // assert
      expect(tvSeriesDetailNotifier.episodeState, RequestState.Loaded);
      expect(tvSeriesDetailNotifier.episodeTvSeries, tEpisodeList);
    });
    test('should change recommendation movies when data is gotten successfully',
        () async {
      // arrange
      _arrangeUseCase();
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      // assert
      expect(tvSeriesDetailNotifier.tvSeriesState, RequestState.Loaded);
      expect(tvSeriesDetailNotifier.recomendedTvSeries, tTvSeriesList);
    });
  });
  group('Get Tv Series Recommendation', () {
    test('should get data from the usecase', () async {
      //arrange
      _arrangeUseCase();
      //act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      //assert
      verify(mockGetRecommendationTvSeries.execute(tId));
      expect(tvSeriesDetailNotifier.recomendedTvSeries, tTvSeriesList);
    });
    test('should change recommendation when data is gotten successfully',
        () async {
      // arrange
      _arrangeUseCase();
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      // assert
      expect(tvSeriesDetailNotifier.recommendedState, RequestState.Loaded);
      expect(tvSeriesDetailNotifier.recomendedTvSeries, tTvSeriesList);
    });
    test('should update error message when request in successful', () async {
      // arrange
      when(mockGetDetailTvSeries.execute(tId))
          .thenAnswer((_) async => Right(testTvSeriesDetail));
      when(mockGetRecommendationTvSeries.execute(tId))
          .thenAnswer((_) async => Left(ServerFailure('Failed')));
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      // assert
      expect(tvSeriesDetailNotifier.recommendedState, RequestState.Error);
      expect(tvSeriesDetailNotifier.message, 'Failed');
    });
  });

  group('Get Episode Tv Series', () {
    test('should get data from the usecase', () async {
      //arrange
      when(mockGetTvSeriesEpisode.execute(tId, tSeason))
          .thenAnswer((_) async => Right(tEpisodeList));
      //act
      await tvSeriesDetailNotifier.fetchTvSeriesEpisode(tId, tSeason);
      //assert
      verify(mockGetTvSeriesEpisode.execute(tId, tSeason));
      expect(tvSeriesDetailNotifier.episodeTvSeries, tEpisodeList);
    });
    test('should change episode when data is gotten successfully', () async {
      // arrange
      when(mockGetTvSeriesEpisode.execute(tId, tSeason))
          .thenAnswer((_) async => Right(tEpisodeList));
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesEpisode(tId, tSeason);
      // assert
      expect(tvSeriesDetailNotifier.episodeState, RequestState.Loaded);
      expect(tvSeriesDetailNotifier.episodeTvSeries, tEpisodeList);
    });
    test('should update error message when request in successful', () async {
      // arrange
      when(mockGetTvSeriesEpisode.execute(tId, tSeason))
          .thenAnswer((_) async => Left(ServerFailure('Failed')));
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesEpisode(tId, tSeason);
      // assert
      expect(tvSeriesDetailNotifier.episodeState, RequestState.Error);
      expect(tvSeriesDetailNotifier.message, 'Failed');
    });
  });

  group('Watchlist', () {
    test('should get the watchlist status', () async {
      //arrange
      when(mockGetWatchlistTvSeriesStatus.execute(tId))
          .thenAnswer((_) async => true);
      //act
      await tvSeriesDetailNotifier.loadWatchlistStatus(tId);
      //assert
      expect(tvSeriesDetailNotifier.isAddedToWatchlist, true);
    });
    test('should execute save watchlist when function called', () async {
      //arrange
      when(mockSaveTvSeriesWatchlist.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Right('Success'));
      when(mockGetWatchlistTvSeriesStatus.execute(tId))
          .thenAnswer((_) async => true);
      //act
      await tvSeriesDetailNotifier.addWatchlist(testTvSeriesDetail);
      //assert
      verify(mockSaveTvSeriesWatchlist.execute(testTvSeriesDetail));
    });
    test('should execute remove watchlist when function called', () async {
      //arrange
      when(mockRemoveWatchlistTvSeries.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Right('Success'));
      when(mockGetWatchlistTvSeriesStatus.execute(tId))
          .thenAnswer((_) async => false);
      //act
      await tvSeriesDetailNotifier.removeWatchlist(testTvSeriesDetail);
      //assert
      verify(mockRemoveWatchlistTvSeries.execute(testTvSeriesDetail));
    });
    test('should update watchlist status when save to watchlist is success',
        () async {
      //arrange
      when(mockSaveTvSeriesWatchlist.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Right('Added to Watchlist'));
      when(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id))
          .thenAnswer((_) async => true);
      //act
      await tvSeriesDetailNotifier.addWatchlist(testTvSeriesDetail);
      //act
      verify(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id));
      expect(tvSeriesDetailNotifier.isAddedToWatchlist, true);
      expect(tvSeriesDetailNotifier.watchlistMessage, 'Added to Watchlist');
      expect(listenerCallCount, 1);
    });
    test('should update watchlist message when save to watchlist is failed',
        () async {
      //arrange
      when(mockSaveTvSeriesWatchlist.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Left(DatabaseFailure('Failed')));
      when(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id))
          .thenAnswer((_) async => true);
      //act
      await tvSeriesDetailNotifier.addWatchlist(testTvSeriesDetail);
      //act
      expect(tvSeriesDetailNotifier.watchlistMessage, 'Failed');
      expect(listenerCallCount, 1);
    });

    test('should update watchlist status when remove from watchlist is success',
        () async {
      //arrange
      when(mockRemoveWatchlistTvSeries.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Right('Removed from Watchlist'));
      when(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id))
          .thenAnswer((_) async => false);
      //act
      await tvSeriesDetailNotifier.removeWatchlist(testTvSeriesDetail);
      //act
      verify(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id));
      expect(tvSeriesDetailNotifier.isAddedToWatchlist, false);
      expect(tvSeriesDetailNotifier.watchlistMessage, 'Removed from Watchlist');
      expect(listenerCallCount, 1);
    });
    test('should update watchlist message when remove from watchlist is failed',
        () async {
      //arrange
      when(mockRemoveWatchlistTvSeries.execute(testTvSeriesDetail))
          .thenAnswer((_) async => Left(DatabaseFailure('Failed')));
      when(mockGetWatchlistTvSeriesStatus.execute(testTvSeriesDetail.id))
          .thenAnswer((_) async => false);
      //act
      await tvSeriesDetailNotifier.removeWatchlist(testTvSeriesDetail);
      //act
      expect(tvSeriesDetailNotifier.watchlistMessage, 'Failed');
      expect(listenerCallCount, 1);
    });
  });
  group('on error', () {
    test('should return error when data is unsuccessful', () async {
      // arrange
      when(mockGetDetailTvSeries.execute(tId))
          .thenAnswer((_) async => Left(ServerFailure('Server Failure')));
      when(mockGetRecommendationTvSeries.execute(tId))
          .thenAnswer((_) async => Right(tTvSeriesList));
      // act
      await tvSeriesDetailNotifier.fetchTvSeriesDetail(tId);
      // assert
      expect(tvSeriesDetailNotifier.tvSeriesState, RequestState.Error);
      expect(tvSeriesDetailNotifier.message, 'Server Failure');
      expect(listenerCallCount, 2);
    });
  });
}
