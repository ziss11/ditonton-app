import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/movie/movie.dart';
import 'package:ditonton/presentation/pages/movie/search_movie_page.dart';
import 'package:ditonton/presentation/provider/movie/movie_search_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';

import 'search_movie_page_test.mocks.dart';

@GenerateMocks([MovieSearchNotifier])
void main() {
  late MockMovieSearchNotifier movieSearchNotifier;

  setUp(() {
    movieSearchNotifier = MockMovieSearchNotifier();
  });

  Widget _makeTestableWidget(Widget body) {
    return ChangeNotifierProvider<MovieSearchNotifier>.value(
      value: movieSearchNotifier,
      child: MaterialApp(
        home: body,
      ),
    );
  }

  testWidgets('Page should display progress bar when loading',
      (WidgetTester tester) async {
    when(movieSearchNotifier.state).thenReturn(RequestState.Loading);

    final loadingWidget = find.byType(CircularProgressIndicator);

    await tester.pumpWidget(_makeTestableWidget(SearchMoviePage()));

    expect(loadingWidget, findsOneWidget);
  });

  testWidgets('Page should display ListView when data is loaded',
      (WidgetTester tester) async {
    when(movieSearchNotifier.state).thenReturn(RequestState.Loaded);
    when(movieSearchNotifier.searchResult).thenReturn(<Movie>[]);

    final listViewFinder = find.byType(ListView);

    await tester.pumpWidget(_makeTestableWidget(SearchMoviePage()));

    expect(listViewFinder, findsOneWidget);
  });

  testWidgets('Page should display empty container when data is error',
      (WidgetTester tester) async {
    when(movieSearchNotifier.state).thenReturn(RequestState.Error);
    when(movieSearchNotifier.searchResult).thenReturn(<Movie>[]);

    final containerFinder = find.byType(Container);

    await tester.pumpWidget(_makeTestableWidget(SearchMoviePage()));

    expect(containerFinder, findsOneWidget);
  });

  testWidgets('Page should display ListView when query id typed',
      (WidgetTester tester) async {
    when(movieSearchNotifier.state).thenReturn(RequestState.Loaded);
    when(movieSearchNotifier.searchResult).thenReturn(<Movie>[]);

    final textfieldFinder = find.byKey(Key('query_input'));

    await tester.pumpWidget(_makeTestableWidget(SearchMoviePage()));
    await tester.enterText(textfieldFinder, 'Free Guy');
    await tester.testTextInput.receiveAction(TextInputAction.done);

    verify(movieSearchNotifier.fetchMovieSearch('Free Guy'));
  });
}
