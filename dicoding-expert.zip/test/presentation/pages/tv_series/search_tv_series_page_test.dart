import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/presentation/pages/tv_series/search_tv_series_page.dart';
import 'package:ditonton/presentation/provider/tv_series/tv_series_search_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';

import 'search_tv_series_page_test.mocks.dart';

@GenerateMocks([TvSeriesSearchNotifier])
void main() {
  late MockTvSeriesSearchNotifier mockTvSeriesSearchNotifier;

  setUp(() {
    mockTvSeriesSearchNotifier = MockTvSeriesSearchNotifier();
  });

  Widget _makeTestableWidget(Widget body) {
    return ChangeNotifierProvider<TvSeriesSearchNotifier>.value(
      value: mockTvSeriesSearchNotifier,
      child: MaterialApp(
        home: body,
      ),
    );
  }

  testWidgets('Page should display progress bar when loading',
      (WidgetTester tester) async {
    when(mockTvSeriesSearchNotifier.searchState)
        .thenReturn(RequestState.Loading);

    final loadingWidget = find.byType(CircularProgressIndicator);

    await tester.pumpWidget(_makeTestableWidget(SearchTvSeriesPage()));

    expect(loadingWidget, findsOneWidget);
  });

  testWidgets('Page should display ListView when data is loaded',
      (WidgetTester tester) async {
    when(mockTvSeriesSearchNotifier.searchState)
        .thenReturn(RequestState.Loaded);
    when(mockTvSeriesSearchNotifier.searchTv).thenReturn(<TvSeries>[]);

    final listViewFinder = find.byType(ListView);

    await tester.pumpWidget(_makeTestableWidget(SearchTvSeriesPage()));

    expect(listViewFinder, findsOneWidget);
  });

  testWidgets('Page should display empty container when data is error',
      (WidgetTester tester) async {
    when(mockTvSeriesSearchNotifier.searchState).thenReturn(RequestState.Error);
    when(mockTvSeriesSearchNotifier.searchTv).thenReturn(<TvSeries>[]);

    final containerFinder = find.byType(Container);

    await tester.pumpWidget(_makeTestableWidget(SearchTvSeriesPage()));

    expect(containerFinder, findsOneWidget);
  });

  testWidgets('Page should display ListView when query id typed',
      (WidgetTester tester) async {
    when(mockTvSeriesSearchNotifier.searchState)
        .thenReturn(RequestState.Loaded);
    when(mockTvSeriesSearchNotifier.searchTv).thenReturn(<TvSeries>[]);

    final textfieldFinder = find.byKey(Key('query_input'));

    await tester.pumpWidget(_makeTestableWidget(SearchTvSeriesPage()));
    await tester.enterText(textfieldFinder, 'Squid Game');
    await tester.testTextInput.receiveAction(TextInputAction.done);

    verify(mockTvSeriesSearchNotifier.fetchSearchTvSeries('Squid Game'));
  });
}
