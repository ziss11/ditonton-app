import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/presentation/pages/tv_series/home_tv_series_page.dart';
import 'package:ditonton/presentation/provider/tv_series/tv_series_list_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';

import 'now_playing_tv_series_test.mocks.dart';

@GenerateMocks([TvSeriesListNotifier])
void main() {
  late MockTvSeriesListNotifier tvSeriesListNotifier;

  setUp(() {
    tvSeriesListNotifier = MockTvSeriesListNotifier();
  });

  Widget _makeTestableWidget(Widget body) {
    return ChangeNotifierProvider<TvSeriesListNotifier>.value(
      value: tvSeriesListNotifier,
      child: MaterialApp(
        home: body,
      ),
    );
  }

  testWidgets('Page should display center progress bar when loading',
      (WidgetTester tester) async {
    when(tvSeriesListNotifier.nowPlayingState).thenReturn(RequestState.Loading);
    when(tvSeriesListNotifier.popularTvSeriessState)
        .thenReturn(RequestState.Loading);
    when(tvSeriesListNotifier.topTvRatedSeriesState)
        .thenReturn(RequestState.Loading);

    final progressBarFinder = find.byType(CircularProgressIndicator);

    await tester.pumpWidget(_makeTestableWidget(HomeTvSeriesPage()));

    expect(progressBarFinder, findsNWidgets(3));
  });

  testWidgets('Page should display ListView when data is loaded',
      (WidgetTester tester) async {
    when(tvSeriesListNotifier.nowPlayingState).thenReturn(RequestState.Loaded);
    when(tvSeriesListNotifier.nowPlayingTvSeriess).thenReturn(<TvSeries>[]);
    when(tvSeriesListNotifier.popularTvSeriessState)
        .thenReturn(RequestState.Loaded);
    when(tvSeriesListNotifier.popularTvSeriess).thenReturn(<TvSeries>[]);
    when(tvSeriesListNotifier.topTvRatedSeriesState)
        .thenReturn(RequestState.Loaded);
    when(tvSeriesListNotifier.topRatedTvSeries).thenReturn(<TvSeries>[]);

    final listViewFinder = find.byType(ListView);

    await tester.pumpWidget(_makeTestableWidget(HomeTvSeriesPage()));

    expect(listViewFinder, findsNWidgets(3));
  });

  testWidgets('Page should display text with message when Error',
      (WidgetTester tester) async {
    when(tvSeriesListNotifier.nowPlayingState).thenReturn(RequestState.Error);
    when(tvSeriesListNotifier.message).thenReturn('Error message');
    when(tvSeriesListNotifier.popularTvSeriessState)
        .thenReturn(RequestState.Error);
    when(tvSeriesListNotifier.message).thenReturn('Error message');
    when(tvSeriesListNotifier.topTvRatedSeriesState)
        .thenReturn(RequestState.Error);
    when(tvSeriesListNotifier.message).thenReturn('Error message');

    final textFinder = find.text('Failed');

    await tester.pumpWidget(_makeTestableWidget(HomeTvSeriesPage()));

    expect(textFinder, findsNWidgets(3));
  });
}
