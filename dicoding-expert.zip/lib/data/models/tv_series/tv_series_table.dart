import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series_detail.dart';
import 'package:equatable/equatable.dart';

class TvSeriesTable extends Equatable {
  final int? id;
  final String? title;
  final String? overview;
  final String? posterPath;

  TvSeriesTable({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
  });

  factory TvSeriesTable.fromJson(Map<String, dynamic> map) => TvSeriesTable(
        id: map['id'],
        title: map['name'],
        overview: map['overview'],
        posterPath: map['poster_path'],
      );

  factory TvSeriesTable.fromEntity(TvSeriesDetail tvSeries) => TvSeriesTable(
        id: tvSeries.id,
        title: tvSeries.title,
        posterPath: tvSeries.posterPath,
        overview: tvSeries.overview,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': title,
        'overview': overview,
        'poster_path': posterPath,
      };

  TvSeries toEntity() => TvSeries.watchlist(
        id: this.id!,
        overview: this.overview,
        posterPath: this.posterPath,
        title: this.title!,
      );

  @override
  List<Object?> get props => [
        id,
        title,
        overview,
        posterPath,
      ];
}
