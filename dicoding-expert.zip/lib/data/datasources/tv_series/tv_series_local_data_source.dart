import 'package:ditonton/common/exception.dart';
import 'package:ditonton/data/datasources/db/database_helper.dart';
import 'package:ditonton/data/models/tv_series/tv_series_table.dart';

abstract class TvSeriesLocalDataSource {
  Future<String> saveTvSeriesWatchlist(TvSeriesTable tvSeries);
  Future<String> removeTvSeriesWatchlist(TvSeriesTable tvSeries);
  Future<TvSeriesTable?> getTvSeriesById(int id);
  Future<List<TvSeriesTable>> getTvSeriesWatchlist();
}

class TvSeriesLocalDataSourceImpl implements TvSeriesLocalDataSource {
  final DatabaseHelper databaseHelper;

  TvSeriesLocalDataSourceImpl({required this.databaseHelper});

  @override
  Future<String> saveTvSeriesWatchlist(TvSeriesTable tvSeries) async {
    try {
      await databaseHelper.insertTvSeriesWatchlist(tvSeries);
      return 'Added to Watchlist';
    } catch (e) {
      throw DatabaseException(e.toString());
    }
  }

  @override
  Future<String> removeTvSeriesWatchlist(TvSeriesTable tvSeries) async {
    try {
      await databaseHelper.deleteTvSeriesWatchlist(tvSeries);
      return 'Removed from Watchlist';
    } catch (e) {
      throw DatabaseException(e.toString());
    }
  }

  @override
  Future<TvSeriesTable?> getTvSeriesById(int id) async {
    final result = await databaseHelper.getTvSeriesById(id);

    if (result != null) {
      return TvSeriesTable.fromJson(result);
    } else {
      return null;
    }
  }

  @override
  Future<List<TvSeriesTable>> getTvSeriesWatchlist() async {
    try {
      final result = await databaseHelper.getTvSeriesWatchlist();
      return result.map((data) => TvSeriesTable.fromJson(data)).toList();
    } catch (e) {
      throw DatabaseException(e.toString());
    }
  }
}
