import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/search_tv_series.dart';
import 'package:flutter/cupertino.dart';

class TvSeriesSearchNotifier extends ChangeNotifier {
  final SearchTvSeries searchTvSeries;

  TvSeriesSearchNotifier({required this.searchTvSeries});

  List<TvSeries> _searchTv = [];
  List<TvSeries> get searchTv => _searchTv;

  RequestState _searchState = RequestState.Empty;
  RequestState get searchState => _searchState;

  String _message = '';
  String get message => _message;

  Future<void> fetchSearchTvSeries(String query) async {
    _searchState = RequestState.Loading;
    notifyListeners();

    final result = await searchTvSeries.execute(query);

    result.fold(
      (failure) {
        _searchState = RequestState.Error;
        _message = failure.message;

        notifyListeners();
      },
      (searchList) {
        _searchState = RequestState.Loaded;
        _searchTv = searchList;

        notifyListeners();
      },
    );
  }
}
