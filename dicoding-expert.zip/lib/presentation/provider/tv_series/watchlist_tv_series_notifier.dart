import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series.dart';
import 'package:flutter/cupertino.dart';

class WatchlistTvSeriesNotifier extends ChangeNotifier {
  final GetWatchlistTvSeries watchlistTvSeries;

  WatchlistTvSeriesNotifier({required this.watchlistTvSeries});

  List<TvSeries> _watchlistTv = [];
  List<TvSeries> get watchlistTv => _watchlistTv;

  RequestState _watchlistState = RequestState.Empty;
  RequestState get watchlistState => _watchlistState;

  String _message = '';
  String get message => _message;

  Future<void> fetchWatchlistTvSeries() async {
    _watchlistState = RequestState.Loading;
    final result = await watchlistTvSeries.execute();

    result.fold((failure) {
      _watchlistState = RequestState.Error;
      _message = failure.message;

      notifyListeners();
    }, (watchlist) {
      _watchlistState = RequestState.Loaded;
      _watchlistTv = watchlist;

      notifyListeners();
    });
  }
}
