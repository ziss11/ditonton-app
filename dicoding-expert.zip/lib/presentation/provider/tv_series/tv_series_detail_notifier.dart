import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series/episode.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series/tv_series_detail.dart';
import 'package:ditonton/domain/usecases/tv_series/get_detail_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_recommendation_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/get_tv_series_episode.dart';
import 'package:ditonton/domain/usecases/tv_series/get_watchlist_tv_series_status.dart';
import 'package:ditonton/domain/usecases/tv_series/remove_watchlist_tv_series.dart';
import 'package:ditonton/domain/usecases/tv_series/save_watchlist_tv_series.dart';
import 'package:flutter/cupertino.dart';

class TvSeriesDetailNotifier extends ChangeNotifier {
  static const addWatchlistSuccesMessage = 'Added to Watchlist';
  static const removeWatchlistSuccesMessage = 'Removed from Watchlist';

  final GetDetailTvSeries getDetailTvSeries;
  final GetRecommendationTvSeries getRecommendationTvSeries;
  final GetWatchlistTvSeriesStatus getWatchListTvSeriesStatus;
  final GetTvSeriesEpisode getTvSeriesEpisode;
  final SaveTvSeriesWatchlist saveTvSeriesWatchlist;
  final RemoveWatchlistTvSeries removeWatchlistTvSeries;

  TvSeriesDetailNotifier({
    required this.getDetailTvSeries,
    required this.getRecommendationTvSeries,
    required this.getWatchListTvSeriesStatus,
    required this.getTvSeriesEpisode,
    required this.removeWatchlistTvSeries,
    required this.saveTvSeriesWatchlist,
  });

  late TvSeriesDetail _tvSeriesDetail;
  TvSeriesDetail get tvSeriesDetail => _tvSeriesDetail;

  RequestState _tvSeriesState = RequestState.Empty;
  RequestState get tvSeriesState => _tvSeriesState;

  List<TvSeries> _recommendedTvSeries = [];
  List<TvSeries> get recomendedTvSeries => _recommendedTvSeries;

  RequestState _recommendedState = RequestState.Empty;
  RequestState get recommendedState => _recommendedState;

  List<Episode> _episodeTvSeries = [];
  List<Episode> get episodeTvSeries => _episodeTvSeries;

  RequestState _episodeState = RequestState.Empty;
  RequestState get episodeState => _episodeState;

  bool _isAddedToWatchlist = false;
  bool get isAddedToWatchlist => _isAddedToWatchlist;

  String _message = '';
  String get message => _message;

  Future<void> fetchTvSeriesDetail(int id) async {
    _tvSeriesState = RequestState.Loading;
    notifyListeners();

    final tvSeriesDetail = await getDetailTvSeries.execute(id);
    final recommendedTvSeries = await getRecommendationTvSeries.execute(id);

    tvSeriesDetail.fold(
      (failure) {
        _tvSeriesState = RequestState.Error;

        _message = failure.message;
        notifyListeners();
      },
      (tvSeriesDetail) {
        _recommendedState = RequestState.Loading;

        _tvSeriesDetail = tvSeriesDetail;
        notifyListeners();

        recommendedTvSeries.fold(
          (failure) {
            _recommendedState = RequestState.Error;
            _message = failure.message;
          },
          (recommendedTvSeries) {
            _recommendedState = RequestState.Loaded;
            _recommendedTvSeries = recommendedTvSeries;
          },
        );
        _tvSeriesState = RequestState.Loaded;
        notifyListeners();
      },
    );
  }

  Future<void> fetchTvSeriesEpisode(int id, int season) async {
    _episodeState = RequestState.Loading;
    notifyListeners();

    final episodeTvSeries = await getTvSeriesEpisode.execute(id, season);

    episodeTvSeries.fold(
      (failure) {
        _episodeState = RequestState.Error;

        _message = failure.message;
        notifyListeners();
      },
      (episode) {
        _episodeState = RequestState.Loaded;

        _episodeTvSeries = episode;
        notifyListeners();
      },
    );
  }

  String _watchlistMessage = '';
  String get watchlistMessage => _watchlistMessage;

  Future<void> addWatchlist(TvSeriesDetail tvSeries) async {
    final result = await saveTvSeriesWatchlist.execute(tvSeries);

    result.fold(
      (failure) async {
        _watchlistMessage = failure.message;
      },
      (succesMessage) async {
        _watchlistMessage = succesMessage;
      },
    );

    await loadWatchlistStatus(tvSeries.id);
  }

  Future<void> removeWatchlist(TvSeriesDetail tvSeries) async {
    final result = await removeWatchlistTvSeries.execute(tvSeries);

    result.fold(
      (failure) async => _watchlistMessage = failure.message,
      (succesMessage) async => _watchlistMessage = succesMessage,
    );

    await loadWatchlistStatus(tvSeries.id);
  }

  Future<void> loadWatchlistStatus(int id) async {
    final result = await getWatchListTvSeriesStatus.execute(id);

    _isAddedToWatchlist = result;
    notifyListeners();
  }
}
